export interface User {
    id: number;
    picture: string;
    age: number;
    name: string;
    gender: string;
    caste:string;
}